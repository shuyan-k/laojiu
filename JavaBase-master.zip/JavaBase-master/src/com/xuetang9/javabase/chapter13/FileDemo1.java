package com.xuetang9.javabase.chapter13;
public class FileDemo1{
	public static void main(String[] args){
		System.out.println("HelloWorld!");
	}
}