package com.xuetang9.javabase.chapter8.guessdemo;

public class TestMain {

	public static void main(String[] args) {
//		HumanPlayer player1 = new HumanPlayer();
//		player1.sendMessage(HumanPlayer.MessageTypeWin);
		
		new GameRoom("�Ͼž�����Ϸ����", "123");
	}

}
