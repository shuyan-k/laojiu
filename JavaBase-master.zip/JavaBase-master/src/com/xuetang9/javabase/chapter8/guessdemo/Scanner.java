package com.xuetang9.javabase.chapter8.guessdemo;

public class Scanner {
	public static void main(String[] args) {
		java.util.Scanner input = new java.util.Scanner(System.in);
		
	}
}
