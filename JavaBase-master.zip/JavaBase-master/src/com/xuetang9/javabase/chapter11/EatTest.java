package com.xuetang9.javabase.chapter11;

public class EatTest {

	public static void main(String[] args) {
		Mouth mouth = new Mouth();
		mouth.eating();

	}

}
