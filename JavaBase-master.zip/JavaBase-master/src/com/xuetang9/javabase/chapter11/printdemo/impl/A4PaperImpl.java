package com.xuetang9.javabase.chapter11.printdemo.impl;

import com.xuetang9.javabase.chapter11.printdemo.iface.IPaper;

public class A4PaperImpl implements IPaper{

	@Override
	public String getSize() {
		// TODO Auto-generated method stub
		return "A4";
	}

}
