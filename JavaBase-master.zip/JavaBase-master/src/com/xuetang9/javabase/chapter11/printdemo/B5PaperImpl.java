package com.xuetang9.javabase.chapter11.printdemo;

import com.xuetang9.javabase.chapter11.printdemo.iface.IPaper;

public class B5PaperImpl implements IPaper{

	@Override
	public String getSize() {
		// TODO Auto-generated method stub
		return "B5";
	}

}
