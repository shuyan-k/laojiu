package com.xuetang9.javabase.chapter11.printdemo.impl;

import com.xuetang9.javabase.chapter11.printdemo.iface.IInkBox;

public class ColorInkBoxImpl implements IInkBox{

	@Override
	public String getColor() {
		return "��ɫ";
	}

}
