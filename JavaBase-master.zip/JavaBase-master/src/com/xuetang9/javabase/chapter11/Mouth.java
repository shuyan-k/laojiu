package com.xuetang9.javabase.chapter11;

public class Mouth implements Eat, Eat1{

	@Override
	public void eating() {
		// TODO Auto-generated method stub
		Eat1.super.eating();
	}

}
